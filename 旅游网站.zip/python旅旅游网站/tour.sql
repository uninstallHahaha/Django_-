-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2020-03-10 13:05:26
-- 服务器版本： 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tour`
--

-- --------------------------------------------------------

--
-- 表的结构 `auth_group`
--

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL,
  `name` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_group_permissions`
--

CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_permission`
--

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_permission`
--

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can add permission', 2, 'add_permission'),
(5, 'Can change permission', 2, 'change_permission'),
(6, 'Can delete permission', 2, 'delete_permission'),
(7, 'Can add group', 3, 'add_group'),
(8, 'Can change group', 3, 'change_group'),
(9, 'Can delete group', 3, 'delete_group'),
(10, 'Can add user', 4, 'add_user'),
(11, 'Can change user', 4, 'change_user'),
(12, 'Can delete user', 4, 'delete_user'),
(13, 'Can add content type', 5, 'add_contenttype'),
(14, 'Can change content type', 5, 'change_contenttype'),
(15, 'Can delete content type', 5, 'delete_contenttype'),
(16, 'Can add session', 6, 'add_session'),
(17, 'Can change session', 6, 'change_session'),
(18, 'Can delete session', 6, 'delete_session'),
(19, 'Can add 旅游攻略', 7, 'add_article'),
(20, 'Can change 旅游攻略', 7, 'change_article'),
(21, 'Can delete 旅游攻略', 7, 'delete_article'),
(22, 'Can add 评论', 8, 'add_comment'),
(23, 'Can change 评论', 8, 'change_comment'),
(24, 'Can delete 评论', 8, 'delete_comment'),
(25, 'Can add 用户', 9, 'add_extuser'),
(26, 'Can change 用户', 9, 'change_extuser'),
(27, 'Can delete 用户', 9, 'delete_extuser'),
(28, 'Can add 酒店', 10, 'add_hotel'),
(29, 'Can change 酒店', 10, 'change_hotel'),
(30, 'Can delete 酒店', 10, 'delete_hotel'),
(31, 'Can add 评分', 11, 'add_score'),
(32, 'Can change 评分', 11, 'change_score'),
(33, 'Can delete 评分', 11, 'delete_score'),
(34, 'Can add 景点', 12, 'add_view'),
(35, 'Can change 景点', 12, 'change_view'),
(36, 'Can delete 景点', 12, 'delete_view'),
(37, 'Can add 订单', 13, 'add_order'),
(38, 'Can change 订单', 13, 'change_order'),
(39, 'Can delete 订单', 13, 'delete_order');

-- --------------------------------------------------------

--
-- 表的结构 `auth_user`
--

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_user`
--

INSERT INTO `auth_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`) VALUES
(1, 'pbkdf2_sha256$36000$JN4camcfD7uL$vaEAcoPjlLH7PMjkTlJVP1BPRT7idAwK1TDTyGAOqXA=', '2020-02-14 06:10:20.542116', 1, 'False', '', '', 'admin@126.com', 1, 1, '2020-02-11 12:56:29.001807'),
(2, 'pbkdf2_sha256$36000$IlGkSJYzHJzW$vOMAS+iXg3gPhG3fiK9HuVjD1SvmOZpMqXCTpLGtr5Q=', '2020-02-14 08:30:33.969214', 0, 'test', '', '', '879510745@128.com', 0, 1, '2020-02-14 07:00:01.879859'),
(3, 'pbkdf2_sha256$36000$cITkT0WlLITd$JaLtPT66YEUAsQj2VvcjRFnVVb+ntg8I23f2RGjtguw=', '2020-03-09 11:54:13.449810', 0, 'qaz', '', '', '123@126.com', 0, 1, '2020-03-09 11:54:13.001784');

-- --------------------------------------------------------

--
-- 表的结构 `auth_user_groups`
--

CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `auth_user_user_permissions`
--

CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `django_admin_log`
--

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) UNSIGNED NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_admin_log`
--

INSERT INTO `django_admin_log` (`id`, `action_time`, `object_id`, `object_repr`, `action_flag`, `change_message`, `content_type_id`, `user_id`) VALUES
(1, '2020-02-11 13:09:23.594062', '1', '云南-昆明-大明湖-1', 1, '[{\"added\": {}}]', 12, 1),
(2, '2020-02-11 13:18:47.555136', '1', '昆明泉世纪大酒店', 1, '[{\"added\": {}}]', 10, 1),
(3, '2020-02-11 13:21:18.704987', '2', '润恒大酒店(人民西路店)', 1, '[{\"added\": {}}]', 10, 1),
(4, '2020-02-14 06:12:55.548603', '1', '云南-昆明-翠湖公园-1', 2, '[{\"changed\": {\"fields\": [\"img\", \"view_name\", \"view_desc\"]}}]', 12, 1),
(5, '2020-02-14 06:13:51.746115', '2', '云南-昆明-大观楼-2', 1, '[{\"added\": {}}]', 12, 1),
(6, '2020-02-14 06:14:34.859114', '3', '云南-昆明-海埂公园-3', 1, '[{\"added\": {}}]', 12, 1),
(7, '2020-02-14 06:15:17.255040', '4', '云南-昆明-海埂公园-4', 1, '[{\"added\": {}}]', 12, 1),
(8, '2020-02-14 06:15:42.303219', '4', '云南-昆明-金殿-4', 2, '[{\"changed\": {\"fields\": [\"view_name\", \"view_desc\"]}}]', 12, 1),
(9, '2020-02-14 06:16:24.858184', '5', '云南-昆明-金马碧鸡坊-5', 1, '[{\"added\": {}}]', 12, 1),
(10, '2020-02-14 06:17:16.845460', '6', '云南-昆明-西山风景区-6', 1, '[{\"added\": {}}]', 12, 1),
(11, '2020-02-14 06:17:55.347321', '7', '云南-昆明-园通寺-7', 1, '[{\"added\": {}}]', 12, 1),
(12, '2020-02-14 06:18:40.760535', '8', '云南-昆明-云南民族村-8', 1, '[{\"added\": {}}]', 12, 1),
(13, '2020-02-14 06:19:25.740618', '9', '云南-昆明-云南省博物馆-9', 1, '[{\"added\": {}}]', 12, 1),
(14, '2020-02-14 06:31:18.098902', '9', '云南-云南省昆明市广福路6393号-云南省博物馆-9', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(15, '2020-02-14 06:31:34.741759', '8', '云南-昆明市西南郊-云南民族村-8', 2, '[{\"changed\": {\"fields\": [\"city\"]}}]', 12, 1),
(16, '2020-02-14 06:31:49.870553', '7', '云南-昆明圆通街-园通寺-7', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(17, '2020-02-14 06:32:04.250305', '6', '云南-昆明市西郊滇池畔-西山风景区-6', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(18, '2020-02-14 06:32:17.990033', '5', '云南-昆明市中心三市街与金碧路汇处-金马碧鸡坊-5', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(19, '2020-02-14 06:32:35.013931', '4', '云南-昆明区东北郊7公里处的鸣凤山麓-金殿-4', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(20, '2020-02-14 06:32:47.353581', '3', '云南-昆明西山区滇池路1318号-海埂公园-3', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(21, '2020-02-14 06:32:59.447236', '2', '云南-昆明西山区大观路284号大观公园-大观楼-2', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(22, '2020-02-14 06:33:08.852730', '1', '云南-昆明五华区翠湖南路67号-翠湖公园-1', 2, '[{\"changed\": {\"fields\": [\"city\", \"view_desc\"]}}]', 12, 1),
(23, '2020-02-14 06:35:53.600479', '3', '春江花月酒店', 1, '[{\"added\": {}}]', 10, 1),
(24, '2020-02-14 06:36:33.944321', '4', '半舍湖畔客栈', 1, '[{\"added\": {}}]', 10, 1),
(25, '2020-02-14 06:38:08.337501', '5', '莲花宾馆', 1, '[{\"added\": {}}]', 10, 1),
(26, '2020-02-14 06:42:16.547452', '6', '恬舍客栈', 1, '[{\"added\": {}}]', 10, 1),
(27, '2020-02-14 06:43:12.815987', '7', '华地王朝大酒店', 1, '[{\"added\": {}}]', 10, 1);

-- --------------------------------------------------------

--
-- 表的结构 `django_content_type`
--

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_content_type`
--

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'auth', 'user'),
(5, 'contenttypes', 'contenttype'),
(6, 'sessions', 'session'),
(7, 'tour', 'article'),
(8, 'tour', 'comment'),
(9, 'tour', 'extuser'),
(10, 'tour', 'hotel'),
(13, 'tour', 'order'),
(11, 'tour', 'score'),
(12, 'tour', 'view');

-- --------------------------------------------------------

--
-- 表的结构 `django_migrations`
--

CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_migrations`
--

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2020-02-11 12:55:42.854927'),
(2, 'auth', '0001_initial', '2020-02-11 12:55:44.555330'),
(3, 'admin', '0001_initial', '2020-02-11 12:55:46.006132'),
(4, 'admin', '0002_logentry_remove_auto_add', '2020-02-11 12:55:46.068532'),
(5, 'contenttypes', '0002_remove_content_type_name', '2020-02-11 12:55:46.411733'),
(6, 'auth', '0002_alter_permission_name_max_length', '2020-02-11 12:55:46.552133'),
(7, 'auth', '0003_alter_user_email_max_length', '2020-02-11 12:55:48.065336'),
(8, 'auth', '0004_alter_user_username_opts', '2020-02-11 12:55:48.096536'),
(9, 'auth', '0005_alter_user_last_login_null', '2020-02-11 12:55:48.283736'),
(10, 'auth', '0006_require_contenttypes_0002', '2020-02-11 12:55:48.299336'),
(11, 'auth', '0007_alter_validators_add_error_messages', '2020-02-11 12:55:48.314936'),
(12, 'auth', '0008_alter_user_username_max_length', '2020-02-11 12:55:48.502137'),
(13, 'sessions', '0001_initial', '2020-02-11 12:55:48.704937'),
(14, 'tour', '0001_initial', '2020-02-11 12:55:52.058943'),
(15, 'tour', '0002_view_img', '2020-02-11 13:05:30.806020'),
(16, 'tour', '0003_extuser_phone', '2020-02-14 06:46:13.590321'),
(17, 'tour', '0004_order', '2020-02-14 12:11:00.167019');

-- --------------------------------------------------------

--
-- 表的结构 `django_session`
--

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `django_session`
--

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('knxp1heo6k4vqoq1lxjjhzcu7tid2q4t', 'NzcxZTQ0M2NmMjdlYWM1ZDI2MTRkOGJkNzlhNzZhMzg3ZTQyNTU5Mjp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyOWU5ZTJkZjY5MTQ4MGQ3NmM0MGFiMjczN2UzNGVkYTM5ZTUxMDViIn0=', '2020-02-28 07:00:02.204877'),
('xffnzdb66z7orbyjru14tbculqc7l2qz', 'YWY2ODc4NjMyNWFkZjEwNThjMzY1NTUzYzU4ZTdmN2E2NmZkNzMzNzp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiI3NWM3N2I0ZDQ0YzQ4MDc1ZjNmZjkwNWNmY2NkMTM0N2YyZjE3YzAyIn0=', '2020-02-25 12:57:40.547555');

-- --------------------------------------------------------

--
-- 表的结构 `tour_article`
--

CREATE TABLE `tour_article` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `time` datetime NOT NULL,
  `author_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tour_article`
--

INSERT INTO `tour_article` (`id`, `title`, `content`, `time`, `author_id`) VALUES
(1, '滇池旅游攻略', '彩云之南，云南昆明，四季如春，不仅仅在气候上吸引着越来越多的游客，更凭着它秀丽的风景，风格多样的食物吸引着越来越多的背包客前来昆明旅游，无论你是跟团行还是自由行，小编都希望以下的攻略对各位读者有那么一点点的帮助，现在就让我们一起去昆明旅游吧\r\n在昆明的交通，如果你是自由行的话，可以选择公交，地铁，出租车到自己想要的景点，小编个人觉得在昆明坐公交是比较方便的，公交直达昆明的大大小小的景点\r\n景点一，石林，石林是形成于2.7亿年前的经典喀斯特地貌，世界的古迹之一，里面都是导游介绍每一个景点，每一块石头的传说给大家，门票大约175元，因为是在郊区，需要打车，或者巴士,火车两小时的车程前往,最好早一点去,这样晚上就可以回来了,在里面还有民族习俗可以参加。\r\n滇池喂海鸥可以说是来昆明的动力之一了（海鸥只有冬天才来哈）滇池也是昆明的标志景点之一。光看图片就好美，成群的海鸥在水面上展翅飞翔，闭上眼睛感受海鸥飞过的阵阵气息，令人陶醉。来昆明不来滇池，算是白来了。\r\n\r\n', '2020-02-14 12:29:08.911524', 2);

-- --------------------------------------------------------

--
-- 表的结构 `tour_comment`
--

CREATE TABLE `tour_comment` (
  `id` int(11) NOT NULL,
  `comment` varchar(255) NOT NULL,
  `comment_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `view_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `tour_extuser`
--

CREATE TABLE `tour_extuser` (
  `number` int(11) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `sex` varchar(2) DEFAULT NULL,
  `address` varchar(30) DEFAULT NULL,
  `autograph` varchar(50) DEFAULT NULL,
  `greet` varchar(50) DEFAULT NULL,
  `labels` varchar(50) DEFAULT NULL,
  `register_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `phone` varchar(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tour_extuser`
--

INSERT INTO `tour_extuser` (`number`, `age`, `sex`, `address`, `autograph`, `greet`, `labels`, `register_date`, `user_id`, `phone`) VALUES
(1054200, 24, '男', '昆明市官渡区', NULL, '你好', NULL, '2020-02-14', 1, '13588887777'),
(4365299, NULL, NULL, NULL, NULL, NULL, NULL, '2020-03-09', 3, NULL),
(7404831, 23, '男', '昆明市官渡区364', NULL, NULL, NULL, '2020-02-14', 2, '13514817716');

-- --------------------------------------------------------

--
-- 表的结构 `tour_hotel`
--

CREATE TABLE `tour_hotel` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `pic` varchar(100) NOT NULL,
  `intro` longtext NOT NULL,
  `price` double NOT NULL,
  `tel` varchar(20) NOT NULL,
  `address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tour_hotel`
--

INSERT INTO `tour_hotel` (`id`, `title`, `pic`, `intro`, `price`, `tel`, `address`) VALUES
(1, '昆明泉世纪大酒店', 'static/upload/1-120326132T5-51.jpg', '昆明泉世纪大酒店 - 云南省昆明市官渡区春城路286', 40, '(0871)64870766', '云南省昆明市官渡区春城路286'),
(2, '润恒大酒店(人民西路店)', 'static/upload/vol20.jpg', '云南省昆明市西山区人民西路42', 166, '(0871)63301066', '云南省昆明市西山区人民西路42'),
(3, '春江花月酒店', 'static/upload/3.png', '春江花月酒店坐落于闻名遐迩的滇池畔，漫步于滇池大坝，舟泛鸥嬉，湖光山色，不胜惬意，云南民族村，海埂公园，西山龙门，大观楼，海埂会堂，滇池国际会展中心等地周围有公交车场、银行、便利店等生活配套设施完善，位置优越、交通便利。 \r\n  它是一所由昆明春江花月酒店管理有限公司精心打造的一家高端精品酒店，各类客房别致、高雅、舒适、独特。', 188, '(0871)64870766', '滇池畔'),
(4, '半舍湖畔客栈', 'static/upload/1.png', '昆明滇池度假区半舍湖畔客栈是昆明一家热门的酒店之一，从酒店到长水国际机场较近，到昆明火车站方便，交通方面均很便捷。包括滇池和云南民族村都在酒店周边，对于入住旅客想在该地区畅游会很方便，服务到位，价格实惠。', 288, '(0871)63301066', '云南省昆明市西山区人民西路42'),
(5, '莲花宾馆', 'static/upload/4.png', '莲花宾馆是一家集住宿、餐饮、娱乐、购物为一体的宾馆，始终致力于为宾客打造温馨舒适、绿色健康的驻足之所，曾获评中国绿色饭店委员会的“四叶级绿色饭店”荣誉。它位于人文气息浓厚的学府路，地理位置得天独厚，周边众多高校林立，附近莲花池公园风景秀丽宜人，距市中心仅5分钟的车程，交通便利。', 168, '(0871)64870743', '云南省昆明市官渡区春城路286'),
(6, '恬舍客栈', 'static/upload/1_Jl8ExQx.png', '旅客若想住在昆明的滇池风景区，那么昆明恬舍客栈将会是一个便捷的选择，交通都很便捷。附近有很多景点，包括云南民族村和滇池', 188, '(0871)64870766', '滇池度假区'),
(7, '华地王朝大酒店', 'static/upload/2.png', '华地王朝大酒店是云南华川集团有限公司旗下的“华地王朝”，位于昆明市高新技术产业开发区内，众多知名企业簇拥，是商务客人入住的优选。酒店设施、配套服务一应俱全，是集住宿、餐饮、娱乐和旅游商务服务为一体的综合性精品商务酒店周边交通便利设施完善。', 399, '(0871)63301066', '云南省昆明市高新技术产业开发区');

-- --------------------------------------------------------


--
-- 表的结构 `tour_order`
--

CREATE TABLE `tour_order` (
  `id` int(11) NOT NULL,
  `num` int(11) NOT NULL,
  `price` double NOT NULL,
  `date` varchar(20) NOT NULL,
  `time` datetime NOT NULL,
  `hotel_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tour_order`
--

INSERT INTO `tour_order` (`id`, `num`, `price`, `date`, `time`, `hotel_id`, `user_id`) VALUES
(1, 2, 376, '2020-01-02', '2020-02-14 12:13:20.222836', 3, 2),
(2, 1, 40, '2020-01-02', '2020-03-09 12:00:23.233960', 1, 3);

-- --------------------------------------------------------

--
-- 表的结构 `tour_score`
--

CREATE TABLE `tour_score` (
  `id` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `comment_date` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `view_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `tour_view`
--

CREATE TABLE `tour_view` (
  `id` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `province` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `view_name` varchar(25) NOT NULL,
  `view_desc` longtext NOT NULL,
  `view_rate` varchar(5) NOT NULL,
  `advise_time` varchar(20) NOT NULL,
  `img` varchar(100)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `tour_view`
--

INSERT INTO `tour_view` (`id`, `price`, `province`, `city`, `view_name`, `view_desc`, `view_rate`, `advise_time`, `img`) VALUES
('1', 30, '云南', '昆明五华区翠湖南路67号', '凉拌鸡丝', '炎炎夏日，又闷又热，有多少人宁愿三餐将就也不想做饭。但是想到这个凉拌鸡丝的美味，我擦一下嘴角的口水，毅然走进了厨房。也许你会怀疑：不过是凉拌鸡丝而已，有什么好馋的？我告诉你，这是一般的鸡丝，不一般的是那个凉拌汁。', '2', '2', 'static/upload/4f.jpg'),
('2', 23, '云南', '昆明西山区大观路284号大观公园', '钵钵鸡', '钵钵鸡是一种四川传统名小吃，属于川菜系。从清代流传至今已有上百年的历史。是以陶器钵盛放配以麻辣为主的佐料，加上多种调料的去骨鸡片拌和而成。有皮脆肉嫩，麻辣鲜香，甜咸适中的特色。吃奶汤面时配以钵钵鸡，别具风格。', '2', '2', 'static/upload/3f.jpg'),
('3', 25, '云南', '昆明西山区滇池路1318号', '凉拌折耳根', '凉拌折耳根是一道菜品，制作原料主要为新鲜折耳根。凉拌折耳根脆嫩爽口，富有折耳根特有的芳香，细细咀嚼，越嚼越香。基本介绍 凉拌折耳根原产地为四川、云南、贵州、重庆等周边地区', '4', '2', 'static/upload/2f.jpg'),
('4', 41, '云南', '昆明区东北郊7公里处的鸣凤山麓', '红烧兔头', '红烧兔头是山东省临沂市沂水、蒙阴等地方著名的传统小吃，属于传统鲁菜。红烧兔头选用3-4个月龄肉食兔子头和10余种蒙山纯天然中药材，经过10余种工序烧制而成。', '4', '2', 'static/upload/1f.jpg'),
('5', 50, '云南', '昆明市中心三市街与金碧路汇处', '麻辣纸包鱼', '纸包鱼是有烤鱼演变而来的,健康环保,口味多种,男女老少皆宜食用 纸包鱼特点: 优点一: 味道独特。口感上外表焦香、内里细嫩,鱼肉特别入味。', '4', '1', 'static/upload/5f.jpg'),
('6', 20, '云南', '昆明市西郊滇池畔', '麻辣蹄花', '重庆麻辣水煮蹄花的做法步骤1先用清水洗净 2在用把猪蹄放锅里用开水小煮一下,水沸腾后就可以把水倒掉,可以去味。 3煎炒调料,这步需要一点时间 4调料炒好后就放入猪蹄先煎炒一下 ', '4', '3', 'static/upload/6f.jpg'),
('7', 30, '云南', '昆明圆通街', '串串香', '串串香，起源于四川成都，不仅是四川地区的特色传统小吃之一，也是草根美食最大众化的体现，串串香实际上是火锅的另一种形式，所以人们又往往称其为小火锅。“串串香”名字的由来是因为这是一种以竹签串上各种菜，将其放进滚烫的火锅中涮着吃的小吃。', '4', '2', 'static/upload/7f.jpg'),
('8', 60, '云南', '昆明市西南郊', '豆汁脑花', '不得不说作为一个另类北方人有的时候还是很佩服自己的,维尼可以吃折耳根,脑花,豆汁儿等等这些所谓的黑暗料理都是一秒入坑。 现在回忆起第一次吃脑花是在火锅店,', '5', '2', 'static/upload/8f.jpg'),
('9', 40, '云南', '云南省昆明市广福路6393号', '鸡汁豆腐', '鸡汁豆腐 林舒 “这是一道凉菜,可做为冷盘用。用东北本地产的黄豆做成的干豆腐豆香浓郁,加上鸡汤的卤制到最后的熏制,更增加了豆腐的口感,回味无穷。', '5', '3', 'static/upload/9f.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auth_group`
--
ALTER TABLE `auth_group`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  ADD KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`);

--
-- Indexes for table `auth_user`
--
ALTER TABLE `auth_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  ADD KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`);

--
-- Indexes for table `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  ADD KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`);

--
-- Indexes for table `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  ADD KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `django_content_type`
--
ALTER TABLE `django_content_type`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`);

--
-- Indexes for table `django_migrations`
--
ALTER TABLE `django_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `django_session`
--
ALTER TABLE `django_session`
  ADD PRIMARY KEY (`session_key`),
  ADD KEY `django_session_expire_date_a5c62663` (`expire_date`);

--
-- Indexes for table `tour_article`
--
ALTER TABLE `tour_article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tour_article_author_id_ad5b0707_fk_auth_user_id` (`author_id`);

--
-- Indexes for table `tour_comment`
--
ALTER TABLE `tour_comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tour_comment_user_id_a2210cf3_fk_auth_user_id` (`user_id`),
  ADD KEY `tour_comment_view_id_eac5dfd6_fk_tour_view_id` (`view_id`);

--
-- Indexes for table `tour_extuser`
--
ALTER TABLE `tour_extuser`
  ADD PRIMARY KEY (`number`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `tour_hotel`
--
ALTER TABLE `tour_hotel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_order`
--
ALTER TABLE `tour_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tour_order_hotel_id_1c0afd74_fk_tour_hotel_id` (`hotel_id`),
  ADD KEY `tour_order_user_id_6a18bb79_fk_auth_user_id` (`user_id`);

--
-- Indexes for table `tour_score`
--
ALTER TABLE `tour_score`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tour_score_user_id_9985049e_fk_auth_user_id` (`user_id`),
  ADD KEY `tour_score_view_id_eccd442e_fk_tour_view_id` (`view_id`);

--
-- Indexes for table `tour_view`
--
ALTER TABLE `tour_view`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `auth_group`
--
ALTER TABLE `auth_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `auth_permission`
--
ALTER TABLE `auth_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- 使用表AUTO_INCREMENT `auth_user`
--
ALTER TABLE `auth_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `django_admin_log`
--
ALTER TABLE `django_admin_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- 使用表AUTO_INCREMENT `django_content_type`
--
ALTER TABLE `django_content_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- 使用表AUTO_INCREMENT `django_migrations`
--
ALTER TABLE `django_migrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- 使用表AUTO_INCREMENT `tour_article`
--
ALTER TABLE `tour_article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `tour_comment`
--
ALTER TABLE `tour_comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `tour_hotel`
--
ALTER TABLE `tour_hotel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- 使用表AUTO_INCREMENT `tour_order`
--
ALTER TABLE `tour_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `tour_score`
--
ALTER TABLE `tour_score`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 限制导出的表
--

--
-- 限制表 `auth_group_permissions`
--
ALTER TABLE `auth_group_permissions`
  ADD CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`);

--
-- 限制表 `auth_permission`
--
ALTER TABLE `auth_permission`
  ADD CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`);

--
-- 限制表 `auth_user_groups`
--
ALTER TABLE `auth_user_groups`
  ADD CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  ADD CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `auth_user_user_permissions`
--
ALTER TABLE `auth_user_user_permissions`
  ADD CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  ADD CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `django_admin_log`
--
ALTER TABLE `django_admin_log`
  ADD CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  ADD CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `tour_article`
--
ALTER TABLE `tour_article`
  ADD CONSTRAINT `tour_article_author_id_ad5b0707_fk_auth_user_id` FOREIGN KEY (`author_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `tour_comment`
--
ALTER TABLE `tour_comment`
  ADD CONSTRAINT `tour_comment_user_id_a2210cf3_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `tour_comment_view_id_eac5dfd6_fk_tour_view_id` FOREIGN KEY (`view_id`) REFERENCES `tour_view` (`id`);

--
-- 限制表 `tour_extuser`
--
ALTER TABLE `tour_extuser`
  ADD CONSTRAINT `tour_extuser_user_id_9728d73a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `tour_order`
--
ALTER TABLE `tour_order`
  ADD CONSTRAINT `tour_order_hotel_id_1c0afd74_fk_tour_hotel_id` FOREIGN KEY (`hotel_id`) REFERENCES `tour_hotel` (`id`),
  ADD CONSTRAINT `tour_order_user_id_6a18bb79_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`);

--
-- 限制表 `tour_score`
--
ALTER TABLE `tour_score`
  ADD CONSTRAINT `tour_score_user_id_9985049e_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  ADD CONSTRAINT `tour_score_view_id_eccd442e_fk_tour_view_id` FOREIGN KEY (`view_id`) REFERENCES `tour_view` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
